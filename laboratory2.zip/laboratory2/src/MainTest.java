import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {
    @Test
    void polybiusCipher() {
        assertAll(
                () -> assertEquals("23343215", Main.polybiusCipher("home")),
                () -> assertEquals(true, Main.saveToFile("23343215")),
                () -> assertEquals("23343215", Main.readFromFile("23343215")),
                () -> assertEquals("home", Main.decryptPolybiusCipher("23343215"))
        );
        assertAll(
                () -> assertEquals("121133", Main.polybiusCipher("ban")),
                () -> assertEquals(true, Main.saveToFile("121133")),
                () -> assertEquals("121133", Main.readFromFile("121133")),
                () -> assertEquals("ban", Main.decryptPolybiusCipher("121133"))
        );
        assertAll(
                () -> assertEquals("22343114", Main.polybiusCipher("gold")),
                () -> assertEquals(true, Main.saveToFile("22343114")),
                () -> assertEquals("22343114", Main.readFromFile("22343114")),
                () -> assertEquals("gold", Main.decryptPolybiusCipher("22343114"))
        );
    }
}
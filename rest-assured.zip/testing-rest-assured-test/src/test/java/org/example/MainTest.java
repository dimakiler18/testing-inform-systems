package org.example;

import org.junit.jupiter.api.Test;

class MainTest {
    @Test
    public void get_users_test() {
        Main.get_users();
    }
}